﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using P111_Core.Models;
using P111_Core.ViewModels;

namespace P111_Core.Controllers
{
    public class ImagesController : Controller
    {
        public IActionResult Index()
        {
            ViewBag.Address = "Images Action";
            ViewBag.Name = "Cavid";

            StudentImage studentImage = new StudentImage
            {
                Students = Images.GetStudents(),
                AllImage = Images.GetImages(),
                Numbers = Images.GetNumbers()
            };

            return View(studentImage);
        }

        public IActionResult Image(int id)
        {
            Image image = Images.GetImages().Where(i => i.Id == id).FirstOrDefault();

            //if (image == null)
            //{
            //    return NotFound();
            //}

            return File("~/img/"+image.Link,"image/jpg");
        }
    }
}