﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;

namespace P111_Core.Controllers
{
    public class HomeController : Controller
    {
        public IActionResult Index()
        {
            ViewBag.Address = "Images Action";
            return View();
        }

        public IActionResult Error()
        {
            return Content("Siz gonderdiyiniz url duzgun deyil !!!");
        }
    }
}