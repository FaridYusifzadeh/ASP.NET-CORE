﻿using P111_Core.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace P111_Core.ViewModels
{
    public class StudentImage
    {
        public List<Image> AllImage { get; set; }
        public string[] Students { get; set; }

        public int[] Numbers { get; set; }
    }
}
